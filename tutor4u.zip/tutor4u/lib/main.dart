import 'package:flutter/material.dart';
import 'package:tutor4u/screens/registration_page.dart';
import 'screens/login_page.dart';

void main() => runApp(tutor4u());

// ignore: camel_case_types
class tutor4u extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: Registration_Page.id,
      routes: {
        login_Page.id: (context) => login_Page(),
        Registration_Page.id: (context) => Registration_Page(),
      },
    );
  }
}
