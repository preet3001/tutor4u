import 'package:flutter/material.dart';
import 'package:tutor4u/constants.dart';

class Fields extends StatelessWidget {
  Fields({@required this.text});
  final String text;
  String Value;
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 2,
            child: Text(
              text,
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            flex: 5,
            child: TextField(
              textAlign: TextAlign.end,
              onChanged: (value) {
                Value = value;
              },
              decoration: kTextFieldDecoration,
            ),
          ),
        ],
      ),
    );
  }
}
