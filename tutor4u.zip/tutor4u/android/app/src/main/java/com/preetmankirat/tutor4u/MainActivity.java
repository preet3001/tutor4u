package com.preetmankirat.tutor4u;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
